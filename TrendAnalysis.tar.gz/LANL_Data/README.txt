In this folder you find all necessary information to reproduce our trend analysis. 

In the file LANL_TotalData.csv you find amongst others: 

* the ID of the sequences
* the Envelope sequences
* the year
* the assigned time period (where 0 has to be discarded)
* the predicted coreceptor with geno2pheno_coreceptor. 
* The predicted IC50 value of our regression models for each bNAb

This allows you to use any test you want on our predictions but also to run your method on the same data. 
