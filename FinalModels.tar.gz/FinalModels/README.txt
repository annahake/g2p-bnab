In this folder you find all necessary information to reproduce our performances or to compare your method on our data. 
For each of the 11 considered bNAbs you find 
* Data.csv file with: 
	GenbankID and PaperID
	Envelope sequence
	Aligned envelope sequence
	IC50 value (51 denotes that IC50 was larger than 50)
	IC50 label 
* Our final oligo kernel for this bNAb
* The resampling instance for the 10 runs of stratified 5-fold cross-validation

If you want to reproduce our results, you just need to run any svm function that is able to handle custom kernels (f.ex. ksvm from the kernlab R package) with the training data and the kernel. The parameter for the cost parameter can be found in param.csv. 

If you want to compare your method with our method, you can take the same data as well as resampling instance to ensure comparability.
